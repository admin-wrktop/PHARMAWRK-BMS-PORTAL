<template>
	<v-card class="elevation-0">
		<SignInDialog
			:sign_in_dialog="sign_in_dialog"
			@clicked="SignInDialogEmit"
		/>
		<v-row no-gutters>
			<v-col cols="12" sm="12" md="12" xs="12">
				<v-toolbar>
					<v-card class="elevation-0" width="130px">
						<v-img src="@/assets/logo.jpg"></v-img>
					</v-card>
					<v-spacer></v-spacer>
					<v-btn
						color="primary"
						style="border-radius:20px"
						class="ml-2"
						@click="sign_in_dialog = true"
						>Sign In</v-btn
					>
				</v-toolbar>
			</v-col>
			<v-col cols="12" sm="12" md="12" xs="12">
				<v-card class="elevation-0">
					<v-img :height="CardHeight" src="@/assets/login.jpg" />
				</v-card>
			</v-col>
		</v-row>
	</v-card>
</template>
<script>
import SignInDialog from '@/components/Dialogs/SignInDialog.vue';
export default {
	components: {
		SignInDialog,
	},
	data: () => ({
		center: { lat: 13.080954, lng: 77.559688 },
		markers: [],
		places: [],
		tab: 0,
		CountryCodeItems: ['+91'],
		sign_in_dialog: false,
		model: 0,
		CardHeight: 0,
		MapHeight: 0,
		colors: ['primary', 'secondary', 'yellow darken-2', 'red', 'orange'],
	}),
	mounted() {
		this.CardHeight = window.innerHeight - 65;
	},
	methods: {
		SignInDialogEmit() {
			this.sign_in_dialog = false;
		},
	},
};
</script>
